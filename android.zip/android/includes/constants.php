<?php
    define('DB_NAME','train_up');
    define('DB_USER','tableplus');
    define('DB_PASSWORD','password');
    define('DB_HOST','127.0.0.1');

?>